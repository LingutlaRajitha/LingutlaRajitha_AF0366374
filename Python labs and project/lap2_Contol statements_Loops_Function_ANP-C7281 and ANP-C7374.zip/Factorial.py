#Factorial of a given number
#Take the input from user
num=int(input("Enter a number:"))
#Initialize the fact value to one
fact=1
#Take the for loop
for i in range(1,num+1):
    fact=fact*i
#Print the factorial of a given number
print(fact)
