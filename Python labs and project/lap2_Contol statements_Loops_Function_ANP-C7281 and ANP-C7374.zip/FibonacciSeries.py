#Fibonacci series between 0 to 50
first=0
second=1
print(first)
print(second)
for i in range(0,49):
    third=first+second
    first=second
    second=third
    if(third<50):
        print(third)
