#Calculate the sum of no. from 1 to 10
#Initialize the sum equal to zero
sum=0
#Take the for loop in the range of 1 to 10
for i in range(1,11):
    sum +=i
#Print the sum 
print(sum)
