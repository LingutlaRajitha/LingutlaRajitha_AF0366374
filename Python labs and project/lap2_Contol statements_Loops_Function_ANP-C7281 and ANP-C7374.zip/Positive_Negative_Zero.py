#Find the given number is positive, negative or zero
#Take the input from user
num=int(input("Enter a number:"))
if(num<0):
    print("Given number is negative")
elif(num>0):
    print("Given number is positive")
else:
    print("Given number is zero")
