import numpy as np

category1_revenue = np.array([500, 600, 700, 550])
category2_revenue = np.array([450, 700, 800, 600])

total_revenue = category1_revenue + category2_revenue

print("Total Revenue:", total_revenue)
