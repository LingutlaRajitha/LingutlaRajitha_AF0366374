import numpy as np

# Input inventory array
inventory = np.array([10, 0, 5, 0, 20, 0])

# Find the indices of elements with quantity 0
out_of_stock_indices = np.where(inventory == 0)

# Output the indices of out of stock products
print("Out of Stock Products:", out_of_stock_indices[0])
