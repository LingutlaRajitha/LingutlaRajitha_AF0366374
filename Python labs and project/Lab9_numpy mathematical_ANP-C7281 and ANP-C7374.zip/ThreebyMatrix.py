import numpy as np

# Create an array with values ranging from 2 to 10
arr = np.arange(2, 11)

# Reshape the array into a 3x3 matrix
matrix = arr.reshape(3, 3)

print("3x3 Matrix with values ranging from 2 to 10:")
print(matrix)
