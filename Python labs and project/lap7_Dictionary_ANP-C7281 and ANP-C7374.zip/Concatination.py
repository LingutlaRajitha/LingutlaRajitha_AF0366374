# Sample Dictionaries
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}

# Create a new dictionary
concatenated_dict = {}

# Concatenate the dictionaries
concatenated_dict.update(dic1)
concatenated_dict.update(dic2)
concatenated_dict.update(dic3)

# Print the concatenated dictionary
print("Concatenated Dictionary:", concatenated_dict)
