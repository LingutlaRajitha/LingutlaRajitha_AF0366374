# Given dictionary
test_dict = {"A": 6, "B": 9, "C": 5, "D": 7, "E": 4}

# Calculate the mean
mean_value = sum(test_dict.values()) / len(test_dict)

# Print the mean
print("Mean:", mean_value)
