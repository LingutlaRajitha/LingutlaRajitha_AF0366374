import pandas as pd

# Input data
students = ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Grace', 'Hannah', 'Ivy', 'Jack']
exam_scores = [92, 88, 76, 94, 82, 90, 85, 89, 78, 91]

# Create Pandas Series
exam_scores_series = pd.Series(exam_scores, index=students, name='Exam Scores')

# Display the Pandas Series
print(exam_scores_series)
