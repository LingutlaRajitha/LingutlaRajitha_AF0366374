# Take input string from the user
input_string = input("Enter a text: ")

# Define vowels
vowels = "aeiouAEIOU"

# Count and display vowels
count = 0
vowel_list = []
for char in input_string:
    if char in vowels:
        count += 1
        vowel_list.append(char)

# Output the count and the vowels
print("Number of vowels:", count)
print("Vowels:", ", ".join(vowel_list))
