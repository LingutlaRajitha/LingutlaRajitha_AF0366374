# Take input string from the user
input_string = input("Enter a string: ")

# Split the string into words
words = input_string.split()

# Reverse the order of words
reversed_words = " ".join(words[::-1])

# Output the reversed string
print("Reversed words:", reversed_words)
