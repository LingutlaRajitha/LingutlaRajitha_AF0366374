# Given string
string = "\nBest \nDeeptech \nPython \nTraining\n"

# Removing newline characters without using functions
string_without_newlines = ""
for char in string:
    if char != '\n':
        string_without_newlines += char

# Output the string without newline characters
print(string_without_newlines)
