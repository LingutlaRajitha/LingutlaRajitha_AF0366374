import numpy as np

# Take the input from the user for the start and end values
start_value = int(input("Enter the start value: "))
end_value = int(input("Enter the end value: "))

# Create a 3x3 matrix with values ranging from start_value to end_value
matrix = np.arange(start_value, end_value+1).reshape(3, 3)

# Display the matrix
print("Sample Output:")
print(matrix)
