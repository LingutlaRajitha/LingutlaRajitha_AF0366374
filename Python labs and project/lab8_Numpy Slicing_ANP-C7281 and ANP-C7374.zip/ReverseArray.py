import numpy as np

# Create an array with values ranging from 12 to 38
array = np.arange(12, 39)

# Reverse the array
array[::-1]

# Display the array
print(array)
