# Input original list from the user
original_list = input("Enter the elements of the list separated by spaces: ").split()

# Convert input elements to integers
original_list = [int(x) for x in original_list]

# Input the length of the first part from the user
length_first_part = int(input("Enter the length of the first part of the list: "))

# Split the list into two parts
first_part = original_list[:length_first_part]
second_part = original_list[length_first_part:]

# Display the splitted list
print("Original list:", original_list)
print("Length of the first part of the list:", length_first_part)
print("Splitted list:", (first_part, second_part))
