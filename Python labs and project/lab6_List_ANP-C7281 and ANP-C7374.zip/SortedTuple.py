# Sample List
sample_list = [(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]

# Custom sorting function to sort based on the second element of each tuple
def sort_by_second_element(tuple_item):
    return tuple_item[1]

# Sort the list based on the second element of each tuple
sorted_list = sorted(sample_list, key=sort_by_second_element)

# Print the sorted list
print("Sorted Result:", sorted_list)
