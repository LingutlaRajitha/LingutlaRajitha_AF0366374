# Sample list
my_list = [1, 2, 3, 4, 5, 2, 7, 8, 8, 3]

# Initialize an empty list to store duplicate values
duplicate_values = []

# Iterate through the list
for value in my_list:
    # Check if the value occurs more than once in the list
    if my_list.count(value) > 1:
        # Add the value to the list of duplicate values if it's not already there
        if value not in duplicate_values:
            duplicate_values.append(value)

# Display the duplicate values
print("Duplicate values:", duplicate_values)
