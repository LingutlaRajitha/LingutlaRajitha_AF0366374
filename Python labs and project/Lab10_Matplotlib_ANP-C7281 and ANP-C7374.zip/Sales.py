import numpy as np
import matplotlib.pyplot as plt

months = np.arange(1,13,0.5)
electronics_sales = np.array([25000, 28000, 31000, 27000, 30000, 32000, 35000, 36000, 38000, 39000, 41000, 42000])
clothing_sales = np.array([15000, 16000, 17000, 18000, 19000, 20000, 21000, 22000, 23000, 24000, 25000, 26000])
home_garden_sales = np.array([18000, 19000, 20000, 21000, 22000, 23000, 24000, 25000, 26000, 27000, 28000, 29000])
sports_outdoors_sales = np.array([12000, 13000, 14000, 15000, 16000, 17000, 18000, 19000, 20000, 21000, 22000, 23000])

plt.suptitle('Sales Performance by Product Categories')

# For Electronics
plt.subplot(2, 2, 1)
plt.plot(months, electronics_sales, marker='o', color='blue')
plt.xlabel('Month')
plt.ylabel('Sales Amount')
plt.title('Electronics')

# For Clothing
plt.subplot(2, 2, 2)
plt.plot(months, clothing_sales, marker='o', color='green')
plt.xlabel('Month')
plt.ylabel('Sales Amount')
plt.title('Clothing')

# For Home & Garden
plt.subplot(2, 2, 3)
plt.plot(months, home_garden_sales, marker='o', color='red')
plt.xlabel('Month')
plt.ylabel('Sales Amount')
plt.title('Home & Garden')

# For Sports & Outdoors
plt.subplot(2, 2, 4)
plt.plot(months, sports_outdoors_sales, marker='o', color='purple')
plt.xlabel('Month')
plt.ylabel('Sales Amount')
plt.title('Sports & Outdoors')

plt.tight_layout()
plt.show()
