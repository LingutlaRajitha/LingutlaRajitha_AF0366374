try:
    # Prompt the user to input the file name
    file_name = input("Enter the name of the file to open: ")

    # Open the file for reading
    with open(file_name, 'r') as file:
        # Read and print the contents of the file
        contents = file.read()
        print("File contents:")
        print(contents)

except FileNotFoundError:
    print("Error: The specified file '{}' does not exist.".format(file_name))
