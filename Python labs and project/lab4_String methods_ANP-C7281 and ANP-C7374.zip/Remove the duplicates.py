#Remove the duplicate characters of a given string
#Take the input from user
String=input("Enter a string:")
#Remove duplicates
result=""
for word in String:
    if word not in result:
        result += word
print(result)
