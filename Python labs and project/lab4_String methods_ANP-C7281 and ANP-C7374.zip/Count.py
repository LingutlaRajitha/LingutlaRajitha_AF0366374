#Program to count all letters, digits and special symbols
#Take the input from user
String =input("Enter a string:")
#Intialize counts
chCount=0
DC=0
Sc=0
#Define valid symbols
symbols="!@#$%^&*()_+{}[]|\/?><"
#Iterate through each character in the given string
for char in String:
    #Check if char is a letter
    if char.isalpha():
        chCount +=1
    #Check if char is a digit
    elif char.isdigit():
        DC +=1
    #Check if char is a symbol
    elif char in symbols:
        Sc +=1
#Print counts
print("char = ", chCount)
print("Digits =", DC)
print("Symbols =", Sc)
