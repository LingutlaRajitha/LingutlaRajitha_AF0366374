#Program to count Uppercase, lowercase,special char and numeric values
#Take the input from user
String=input("Enter a string:")
#Intialize count
Uc=0
Lc=0
Nc=0
Sc=0
#Iterate through each character in the string
for char in String:
    if char.isupper():
        Uc +=1
    elif char.islower():
        Lc +=1
    elif char.isdigit():
        Nc +=1
    else:
        Sc +=1
#print the counts
print("UpperCase:", Uc)
print("LowerCase:", Lc)
print("NumberCase:", Nc)
print("SpecialCase:", Sc)
