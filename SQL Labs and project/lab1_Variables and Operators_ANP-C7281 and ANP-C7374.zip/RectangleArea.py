#Area of a rectangle
#Take the length input from user
length=int(input("Enter length:"))
#Take the width input from user
width=int(input("Enter width:"))
#Formulae of a area of a rectangle
Ar=length*width
#print the output
print("Area of a rectangle: ",Ar)
