#Area of a circle
#Take the radius input from user
radius=int(input("Enter radius:"))
#Constant PI value  
PI=3.14
#Formulae of a area of a circle
AC=3.14*radius**2
#print the output
print("Area of a circle: ",AC)
