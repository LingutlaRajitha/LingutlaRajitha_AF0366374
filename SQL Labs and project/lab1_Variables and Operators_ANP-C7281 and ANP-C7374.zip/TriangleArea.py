#Area of a triangle
#Take the base input from user
base=int(input("Enter base:"))
#Take the height input from user
height=int(input("Enter height:"))
#Formulae of a area of a triangle
At=(0.5)*base*height
#print the output
print("Area of a traingle: ",At)
