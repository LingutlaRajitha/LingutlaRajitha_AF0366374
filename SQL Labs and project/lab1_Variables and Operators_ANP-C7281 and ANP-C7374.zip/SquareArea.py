#Area of a Square
#Take the side input from user
side=int(input("Enter side:"))
#Formulae of a area of a rectangle
As=side**2
#print the output
print("Area of a square: ",As)
